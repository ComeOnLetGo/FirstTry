namespace Sdl.ProjectApi.Implementation
{
	internal interface IFilteredProjectCascadeItem
	{
		ProjectCascadeItem FilteredCascadeItem { get; }
	}
}
