namespace Sdl.ProjectApi.Implementation
{
	public delegate bool ProjectCascadeEntryDataFilterFunction(ProjectCascadeEntryData projectCascadeEntryData);
}
