namespace Sdl.ProjectApi.Implementation
{
	internal interface IOverwriteFileQuestion
	{
		OverwriteFileEventResult ShouldOverwriteFile();
	}
}
