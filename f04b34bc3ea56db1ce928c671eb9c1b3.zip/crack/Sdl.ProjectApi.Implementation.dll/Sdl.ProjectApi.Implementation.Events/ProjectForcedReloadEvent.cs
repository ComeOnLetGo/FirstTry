using System;

namespace Sdl.ProjectApi.Implementation.Events
{
	public class ProjectForcedReloadEvent
	{
		public Guid ProjectGuid { get; set; }
	}
}
