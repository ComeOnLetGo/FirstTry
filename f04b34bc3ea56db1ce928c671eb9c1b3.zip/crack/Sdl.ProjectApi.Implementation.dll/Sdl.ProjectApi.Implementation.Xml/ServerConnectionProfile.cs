namespace Sdl.ProjectApi.Implementation.Xml
{
	internal class ServerConnectionProfile
	{
		public ServerConnectionProfile Copy()
		{
			return (ServerConnectionProfile)MemberwiseClone();
		}
	}
}
