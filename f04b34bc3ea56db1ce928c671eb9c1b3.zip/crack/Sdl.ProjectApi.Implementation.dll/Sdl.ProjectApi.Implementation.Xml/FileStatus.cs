namespace Sdl.ProjectApi.Implementation.Xml
{
	internal class FileStatus
	{
		public FileStatus Copy()
		{
			return (FileStatus)MemberwiseClone();
		}
	}
}
