namespace Sdl.Common.Licensing.Provider.SafeNetRMS
{
	public interface ILoginSession
	{
		void Logout();
	}
}
