using System;
using Sdl.Common.Licensing.Provider.Core;

namespace Sdl.ProjectApi.Implementation.Licensing.Perpetual
{
	public static class ProductLicenseExtensions
	{
		public static bool IsAuthorised(this IProductLicense productLicense)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Invalid comparison between Unknown and I4
			return (int)productLicense.Status == 0;
		}

		public static bool IsNotAuthorised(this IProductLicense productLicense)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Invalid comparison between Unknown and I4
			return (int)productLicense.Status > 0;
		}

		public static int? GetDaysRemainingOnLicense(this IProductLicense productLicense)
		{
			int? result = null;
			DateTime? expirationDate = productLicense.ExpirationDate;
			if (expirationDate.HasValue)
			{
				TimeSpan timeSpan = expirationDate.Value - DateTime.Today;
				result = ((timeSpan.TotalDays > 0.0) ? ((int)Math.Ceiling(timeSpan.TotalDays)) : 0);
			}
			return result;
		}

		public static bool IsFeatureActive(this IProductLicense productLicense, string feature)
		{
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			if (productLicense == null)
			{
				throw new ArgumentNullException("productLicense");
			}
			if ((int)productLicense.Status != 0)
			{
				return false;
			}
			if (string.IsNullOrEmpty(feature))
			{
				return false;
			}
			switch (feature)
			{
			case "AllowOpenDocument":
			case "AllowOpenRemoteProject":
			case "AllowOpenStudioPackage":
				return productLicense.IsLicenseVersion(PerpetualLicenseVersion.NotExpress);
			case "AllowProjectCreation":
			case "AllowTMAdmin":
				return productLicense.IsLicenseVersion(PerpetualLicenseVersion.Freelance | PerpetualLicenseVersion.Professional);
			case "AllowLaunchMultiTerm":
			case "AllowLaunchLegacyApps":
			case "AllowOpenLocalProject":
			case "AllowAlignment":
			case "AllowUpdateFromReviewedTarget":
			case "AllowSupportingApplications":
			case "AllowMultipleTranslationMemories":
			case "AllowUnlimitedTranslationUnits":
			case "AllowServerBasedTranslationMemories":
				return productLicense.IsLicenseVersion(PerpetualLicenseVersion.FullVersion);
			case "AllowPublishProject":
				return productLicense.IsLicenseVersion(PerpetualLicenseVersion.Professional);
			case "AllowTQAForPackageProjects":
				return productLicense.IsLicenseVersion(PerpetualLicenseVersion.Freelance);
			case "AllowPerfectMatch":
			{
				string text = ConvertToPerpetualLicenseFeature(feature);
				if (!productLicense.IsLicenseVersion(PerpetualLicenseVersion.Professional | PerpetualLicenseVersion.WorkGroup))
				{
					if (productLicense.HasFeature(text))
					{
						return productLicense.IsFeatureCheckedOut(text);
					}
					return false;
				}
				return true;
			}
			case "AllowPackageCreation":
			case "AllowCustomTaskSequences":
				return productLicense.IsLicenseVersion(PerpetualLicenseVersion.Professional | PerpetualLicenseVersion.WorkGroup);
			case "AllowDomainExecution":
			case "AllowUnlimitedLanguages":
				return productLicense.IsLicenseVersion(PerpetualLicenseVersion.Express | PerpetualLicenseVersion.Professional | PerpetualLicenseVersion.WorkGroup);
			case "AllowThirdPartyPlugins":
			case "AllowProjectBatchTasks":
			case "AllowProjectTranslationProviderChanges":
			case "AllowProjectTermbaseConfigurationChanges":
				return productLicense.IsLicenseVersion(PerpetualLicenseVersion.NotStarter);
			case "AllowTQA":
			{
				string text = ConvertToPerpetualLicenseFeature(feature);
				if (productLicense.HasFeature(text))
				{
					return productLicense.IsFeatureCheckedOut(text);
				}
				return false;
			}
			default:
				return false;
			}
		}

		private static string ConvertToPerpetualLicenseFeature(string feature)
		{
			if (Enum.TryParse<PerpetualLicenseFeature>(feature, out var result))
			{
				return Convert.ToInt32(result).ToString();
			}
			return null;
		}

		public static bool IsLicenseVersion(this IProductLicense productLicense, PerpetualLicenseVersion version)
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			if (productLicense == null || version == (PerpetualLicenseVersion)0 || (int)productLicense.Status != 0)
			{
				return false;
			}
			PerpetualLicenseVersion licenseType = (PerpetualLicenseVersion)productLicense.LicenseType;
			return (licenseType & version) != 0;
		}

		public static bool IsUnlocked(this IProductLicense productLicense)
		{
			dynamic property = productLicense.GetProperty("Unlocked");
			return property != null && property;
		}

		public static bool IsProfessional(this IProductLicense productLicense)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			if ((int)productLicense.Status == 0)
			{
				return productLicense.LicenseType == 8;
			}
			return false;
		}

		public static bool IsFreelance(this IProductLicense productLicense)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			if ((int)productLicense.Status == 0)
			{
				return productLicense.LicenseType == 4;
			}
			return false;
		}

		public static bool IsStarter(this IProductLicense productLicense, bool includeExpiredStarter = false)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Invalid comparison between Unknown and I4
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Invalid comparison between Unknown and I4
			if (((int)productLicense.Status == 0 || includeExpiredStarter) && (int)productLicense.Mode == 1)
			{
				return productLicense.LicenseType == 2;
			}
			return false;
		}

		public static bool IsExpress(this IProductLicense productLicense)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			if ((int)productLicense.Status == 0)
			{
				return productLicense.LicenseType == 1;
			}
			return false;
		}

		public static bool IsWorkGroup(this IProductLicense productLicense)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			if ((int)productLicense.Status == 0)
			{
				return productLicense.LicenseType == 16;
			}
			return false;
		}

		public static bool IsTrial(this IProductLicense productLicense)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000f: Invalid comparison between Unknown and I4
			if ((int)productLicense.Status == 0)
			{
				return (int)productLicense.Mode == 0;
			}
			return false;
		}

		public static bool IsStarterLicenseInExpiryPeriod(this IProductLicense productLicense)
		{
			if (!productLicense.IsStarter(includeExpiredStarter: true))
			{
				return false;
			}
			int? daysRemainingOnLicense = productLicense.GetDaysRemainingOnLicense();
			if (daysRemainingOnLicense.HasValue)
			{
				return daysRemainingOnLicense.Value <= 30;
			}
			return false;
		}

		public static bool IsTimeLimitedLicenseInExpiryPeriod(this IProductLicense productLicense)
		{
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Invalid comparison between Unknown and I4
			if (productLicense.IsStarter(includeExpiredStarter: true) || (int)productLicense.Mode != 1)
			{
				return false;
			}
			int? daysRemainingOnLicense = productLicense.GetDaysRemainingOnLicense();
			if (daysRemainingOnLicense.HasValue)
			{
				return daysRemainingOnLicense.Value <= 14;
			}
			return false;
		}

		public static string GetFeaturePropertyValue(this IProductLicense productLicense, string featureName, string featurePropertyName)
		{
			ILicenseFeature feature = productLicense.GetFeature(featureName);
			if (feature == null || string.IsNullOrEmpty(feature.Value))
			{
				return null;
			}
			string[] array = feature.Value.Split(';');
			if (array.Length == 0)
			{
				return null;
			}
			string[] array2 = array;
			foreach (string text in array2)
			{
				string[] array3 = text.Split(':');
				if (array3.Length == 2 && string.Equals(featurePropertyName, array3[0], StringComparison.InvariantCultureIgnoreCase))
				{
					return array3[1];
				}
			}
			return null;
		}

		public static int? GetMaxTranslationUnits(this IProductLicense productLicense)
		{
			string featurePropertyValue = productLicense.GetFeaturePropertyValue("StarterEdition", "MaxTranslationUnits");
			if (!string.IsNullOrEmpty(featurePropertyValue))
			{
				return Convert.ToInt32(featurePropertyValue);
			}
			return null;
		}

		public static int? GetMaxTargetLanguages(this IProductLicense productLicense)
		{
			string featurePropertyValue = productLicense.GetFeaturePropertyValue("FreelanceEdition", "MaxTargetLanguages");
			if (!string.IsNullOrEmpty(featurePropertyValue))
			{
				return Convert.ToInt32(featurePropertyValue);
			}
			return null;
		}
	}
}
