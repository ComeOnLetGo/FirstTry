namespace Sdl.ProjectApi.Implementation
{
	public delegate V GetListItemValueDelegate<T, V>(T item);
}
