namespace Sdl.ProjectApi.Implementation.Server
{
	public class Assignee
	{
		public string Id { get; set; }
	}
}
