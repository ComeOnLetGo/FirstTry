namespace Sdl.ProjectApi.Implementation.LanguageCloud
{
	public class RefreshOperationsResult
	{
		public bool WasPerformed { get; set; }
	}
}
