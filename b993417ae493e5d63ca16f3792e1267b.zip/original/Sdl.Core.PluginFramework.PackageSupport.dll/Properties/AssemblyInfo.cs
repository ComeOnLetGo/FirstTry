using System;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("PackageSupport")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("PackageSupport")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("d8c8bcc3-cc4e-45d7-9823-20f8abdb14af")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: CLSCompliant(true)]
[assembly: InternalsVisibleTo("PluginFrameworkUnitTest, PublicKey=002400000480000094000000060200000024000052534131000400000100010013f795cf308f1cb7b368d9dec675d92d677449fe6849aca68a1400e21445c2d01e7e5994b9f2b01306a5208c750e9f7beedc3efac831f003f9a55b391048e7ad665a4c5a8efafc09b636db82394a47285ea8aef41109c693801d167945027381708f96533cc31fc4de1e12bfd440c6c06d0bd712629b1906336e69993bc084c0")]
[assembly: AssemblyCompany("SDL")]
[assembly: AssemblyCopyright("Copyright © 2022 RWS. All rights reserved.")]
[assembly: AssemblyFileVersion("4.0.13.0")]
[assembly: AssemblyVersion("1.8.0.0")]
