namespace Sdl.Core.PluginFramework.PackageSupport
{
	public class OpenExchangeRelationship
	{
		public const string PackageRelationshipType = "http://www.sdl.com/OpenExchange/2010/03/sdlplugin/root-manifest-xml";

		public const string ResourceRelationshipType = "http://www.sdl.com/OpenExchange/2010/03/sdlplugin/required-resource";
	}
}
