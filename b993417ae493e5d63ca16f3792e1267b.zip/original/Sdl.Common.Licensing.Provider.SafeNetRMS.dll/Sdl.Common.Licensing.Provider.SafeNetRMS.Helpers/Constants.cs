namespace Sdl.Common.Licensing.Provider.SafeNetRMS.Helpers
{
	internal static class Constants
	{
		public const int RefreshDisabled = -1;

		public const string LicenseType = "LICENSE_TYPE";

		public const string StandaloneLicense = "1";
	}
}
