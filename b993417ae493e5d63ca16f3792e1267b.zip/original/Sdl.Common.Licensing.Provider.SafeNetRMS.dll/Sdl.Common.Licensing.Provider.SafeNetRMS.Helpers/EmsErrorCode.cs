namespace Sdl.Common.Licensing.Provider.SafeNetRMS.Helpers
{
	internal static class EmsErrorCode
	{
		public const int InsufficientQuantity = 831;

		public const int ProductKeyIncorrect = 220;
	}
}
