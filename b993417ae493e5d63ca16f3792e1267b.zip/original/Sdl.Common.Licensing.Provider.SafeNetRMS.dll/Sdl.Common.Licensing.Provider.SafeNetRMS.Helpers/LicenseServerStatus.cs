namespace Sdl.Common.Licensing.Provider.SafeNetRMS.Helpers
{
	public enum LicenseServerStatus
	{
		LicenseServerRunning,
		LicenseServerHasNoFeatures,
		LicenseServerNotRunning,
		LicenseServerHostNotFound
	}
}
