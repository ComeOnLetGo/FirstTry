using System;
using System.Text;
using Sdl.Common.Licensing.Provider.Core;
using Sdl.Common.Licensing.Provider.SafeNetRMS.Helpers;

namespace Sdl.Common.Licensing.Provider.SafeNetRMS
{
	internal class LicenseFeature : ILicenseFeature
	{
		private readonly FeatureInfo _featureInfo;

		public string Id { get; set; }

		public string Name => _featureInfo.FeatureName;

		public string Version => _featureInfo.Version;

		public bool IsLocked => _featureInfo.IsNodeLocked;

		public bool IsCommuted => _featureInfo.IsCommuted;

		public bool IsAllowedOnVm => _featureInfo.IsAllowedOnVm;

		public int CommuterMaxCheckOutDays => _featureInfo.CommuterMaxCheckOutDays;

		public int LockingCriteria => _featureInfo.LockingCrit;

		public ILoginSession LoginSession { get; internal set; }

		public DateTime? ExpirationDate
		{
			get
			{
				if (_featureInfo.DeathDay != -1)
				{
					return ConvertFromUnixTimestamp(_featureInfo.DeathDay);
				}
				if (_featureInfo.IsTrialLicense)
				{
					return new DateTimeOffset(DateTime.Now).AddDays(_featureInfo.TrialCalendarPeriodLeft).Date;
				}
				return null;
			}
		}

		public int KeyLifetimeSec => _featureInfo.KeyLifetimeSec;

		public int LicenseType => _featureInfo.LicenseType;

		public LicenseMode Mode
		{
			get
			{
				//IL_0001: Unknown result type (might be due to invalid IL or missing references)
				//IL_0010: Unknown result type (might be due to invalid IL or missing references)
				//IL_003f: Unknown result type (might be due to invalid IL or missing references)
				//IL_003e: Unknown result type (might be due to invalid IL or missing references)
				//IL_002c: Unknown result type (might be due to invalid IL or missing references)
				LicenseMode result = (LicenseMode)2;
				if (_featureInfo.IsCommuted)
				{
					result = (LicenseMode)3;
				}
				else if (_featureInfo.IsTrialLicense)
				{
					result = (LicenseMode)(IsLocked ? 1 : 0);
				}
				else if (_featureInfo.DeathDay != -1)
				{
					result = (LicenseMode)1;
				}
				return result;
			}
		}

		public LicenseModeDetails ModeDetail
		{
			get
			{
				//IL_0001: Unknown result type (might be due to invalid IL or missing references)
				//IL_001f: Unknown result type (might be due to invalid IL or missing references)
				//IL_001e: Unknown result type (might be due to invalid IL or missing references)
				LicenseModeDetails result = (LicenseModeDetails)2;
				if (_featureInfo.IsTrialLicense && _featureInfo.TrialCalendarPeriodLeft == 0)
				{
					result = (LicenseModeDetails)9;
				}
				return result;
			}
		}

		public string Value => _featureInfo.VendorInfo;

		public bool HasExpired
		{
			get
			{
				if (ExpirationDate.HasValue)
				{
					DateTime now = DateTime.Now;
					DateTime? expirationDate = ExpirationDate;
					return now > expirationDate;
				}
				return false;
			}
		}

		public bool IsInstalledTrial
		{
			get
			{
				//IL_0001: Unknown result type (might be due to invalid IL or missing references)
				if ((int)Mode == 0)
				{
					return !IsLocked;
				}
				return false;
			}
		}

		public bool IsNetwork => _featureInfo.IsNetwork;

		public LicenseFeature(FeatureInfo featInfo)
		{
			_featureInfo = featInfo;
		}

		public bool IsLoggedIn()
		{
			return LoginSession != null;
		}

		public void Logout()
		{
			try
			{
				LoginSession.Logout();
			}
			finally
			{
				LoginSession = null;
			}
		}

		public void ToString(StringBuilder stringBuilder)
		{
			stringBuilder.AppendLine(_featureInfo.GetDiagonsticData());
		}

		private static DateTime ConvertFromUnixTimestamp(double timestamp)
		{
			return TimeZoneInfo.ConvertTimeFromUtc(new DateTime(1970, 1, 1, 0, 0, 0, 0).AddSeconds(timestamp), TimeZoneInfo.Local);
		}
	}
}
